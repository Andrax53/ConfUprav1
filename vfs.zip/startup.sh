ls /
uname
